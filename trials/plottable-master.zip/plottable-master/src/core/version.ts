module Plottable {
export var version = "@VERSION";
}
