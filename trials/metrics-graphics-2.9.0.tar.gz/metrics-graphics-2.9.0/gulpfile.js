'use strict';

require('./gulp');
